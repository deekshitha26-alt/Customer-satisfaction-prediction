END–TO-END PREDICTIVE ANALYTICS PIPELINE FOR CUSTOMER SATISFACTION USING PYTHON \& NEURAL NETWORKS



&#x20;**Description**



This project is designed to predict customer satisfaction using advanced Neural Network models built with Python. It helps business organizations analyze customer data and make informed decisions by providing accurate satisfaction predictions through both batch and real-time processing.



**Features**

🔹 Batch Prediction (CSV file upload)

🔹 Real-Time Prediction (user input form)

🔹 Interactive Visualizations

🔹 Graphs and Charts for insights

🔹 User-friendly interface using Streamlit



**Technologies Used**

Python

Neural Networks

TensorFlow

Streamlit



**Installation \& Setup**



Create a virtual environment:



python -m venv env



Activate the environment:



cd env

cd Scripts

activate

cd..

cd..



Run the application:



streamlit run app.py



**Usage**

Upload a dataset for batch prediction

Enter customer details for real-time prediction

View results along with graphs and charts



**Application Overview**



The system integrates:



Data preprocessing

Neural network model prediction

Visualization dashboard



All components are connected through an interactive Streamlit web application.





